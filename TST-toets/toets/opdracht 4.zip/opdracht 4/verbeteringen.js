function Verbeteringen() {
    this.item = 'item';
    this.nummer = 2;
    this.unit = 'Unit test';
    this.beschrijving = 'Beschrijving';
    this.boodschap = 'Hallo';

}

let unitTest = new Verbeteringen();
