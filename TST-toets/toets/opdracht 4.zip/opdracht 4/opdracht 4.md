# Opdracht 4. Command-line Jasmine 

## a. Run de testen vanaf de command-line (1 punt)
Herstructureer de code in de bestanden myspecs.spec.js en voorbeeld.js zodat je met de geleerde jasmine commando's uitvoer krijgt zoals hieronder staat.  

Het is niet nodig een HTML bestand aan te maken.

![command line uitvoer](../../screenshots/commandline.png)

## b. Directory structuur (0,5 punt)
Maak een schermprint van de directory structuur van je project en voeg deze afbeelding toe aan je Github repository.

## c. Jasmine commando's (0,5 punt)
- Welke commando('s) heb je nodig om de bovenstaande directory structuur te maken.   
- Welke commando('s) heb je nodig om de testen uit te voeren.
