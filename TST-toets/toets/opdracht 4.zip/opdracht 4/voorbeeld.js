function Voorbeeld() {
    this.voorbeeld;
    this.aantal = 2;
}

let example = new Voorbeeld();
